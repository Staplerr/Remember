//
//  Private_DictionaryApp.swift
//  Private Dictionary
//
//  Created by admin on 22/6/2567 BE.
//

import SwiftUI

@main
struct Private_DictionaryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
